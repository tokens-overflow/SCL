# ============================================================
#  LINE 学校 DX デモ 起動スクリプト
#  - 依存パッケージのインストール
#  - 自己署名 TLS 証明書の生成（HTTPS のため）
#  - HTTPS で uvicorn 起動
# ============================================================
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot   # ソース/ ディレクトリへ移動（app パッケージを import するため）

Write-Host "[1/3] 依存パッケージをインストール中..." -ForegroundColor Cyan
python -m pip install -r requirements.txt

Write-Host "[2/3] 自己署名 TLS 証明書を生成中..." -ForegroundColor Cyan
python -m app.core.tls

Write-Host "[3/3] HTTPS サーバを起動します。" -ForegroundColor Green
Write-Host "  保護者トーク : https://localhost:8443/parent"
Write-Host "  欠席フォーム : https://localhost:8443/liff/absence"
Write-Host "  教員ログイン : https://localhost:8443/admin/login  (admin/admin, teacher/teacher)"
Write-Host "  ※自己署名のため初回はブラウザ警告 → [詳細設定]→[続行] で進んでください"
Write-Host ""

python -m uvicorn app.main:app --host 127.0.0.1 --port 8443 `
    --ssl-keyfile certs/key.pem --ssl-certfile certs/cert.pem
