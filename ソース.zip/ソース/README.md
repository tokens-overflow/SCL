# LINE 学校 DX デモ（ソース）

学校向け DX システムの **PC 単体で動く動作デモ**。LINE 風トーク・LIFF 風欠席
フォーム・教員管理画面を 1 プロセスで提供し、セキュリティ 4 要件を実装で示す。
DB は **インストール不要の SQLite（ファイル DB）**。

## 起動

```powershell
cd C:\NTA\source\Agent-Learning\line-school\ソース
./run.ps1
```

ブラウザで（自己署名のため初回は警告 → 続行）:

| 画面 | URL | 備考 |
|---|---|---|
| 保護者トーク（LINE風） | https://localhost:8443/parent | チャット＋リッチメニュー |
| 欠席フォーム（LIFF風） | https://localhost:8443/liff/absence | AI 非経由 |
| 教員ログイン | https://localhost:8443/admin/login | `admin/admin`(管理者) / `teacher/teacher`(教員) |

### AI（チャットボット）の接続先

- 既定で **Amazon Bedrock 上の Claude Sonnet 4.6** を使用する。認証情報・モデル
  （推論プロファイル `jp.anthropic.claude-sonnet-4-6`）・prompt cache 設定は、
  外部ファイル **`C:\NTA\RooCode\ai.txt`** から実行時に読み込む（秘密情報はソースに
  埋め込まない。パスは環境変数 `BEDROCK_CONFIG_FILE` で変更可）。
- 認証情報が無い／呼び出しに失敗した場合は、**オフライン Stub** に自動フォールバック
  するためデモは止まらない。`USE_BEDROCK=0` で強制的に Stub にもできる。
- いずれの場合も、チャットボットに渡すのは質問文と学習資料のみ（個人情報は渡さない）。

## フォルダ構成（層構造・解耦）

依存方向は **web → services → domain ← infrastructure → core**。
services は domain/ports の抽象のみに依存し、実装（SQLite/Bedrock）は web/deps.py で注入する。

```
ソース/
├── run.ps1                      起動スクリプト（install→証明書→HTTPS起動）
├── requirements.txt
├── knowledge/                   チャットボットの学習資料（RAG 参照元・差し替え可）
│   ├── 学校生活のしおり.md
│   └── よくある質問.md
└── app/
    ├── main.py                  アプリ組み立て（FastAPI・ルータ登録・DB初期化）
    ├── core/                    横断的関心事（最下層・他層に依存しない）
    │   ├── config.py            設定・パス
    │   ├── crypto.py            個人情報のAES-GCM暗号化（要件2）
    │   ├── security.py          パスワードのbcryptハッシュ（要件3）
    │   └── tls.py               自己署名証明書生成（要件2）
    ├── domain/                  業務の中核（実装を持たない）
    │   ├── models.py            ドメインモデル（dataclass）
    │   └── ports.py             抽象IF（Repository / AIProvider / KnowledgeBase）
    ├── infrastructure/          domain/ports の具体実装（外部I/O）
    │   ├── database.py          SQLite接続・スキーマ・シード
    │   ├── repositories.py      SQLiteリポジトリ（暗号化/復号もここ）
    │   ├── knowledge.py         資料検索（RAG・文字2-gram）
    │   ├── ai_stub.py           オフラインAI（既定）
    │   ├── ai_bedrock.py        Bedrock上のClaude
    │   └── ai_factory.py        AI実装の選択（Stub↔Bedrock）
    ├── services/                ユースケース（domain/portsのみに依存）
    │   ├── message_router.py    ★要件4: 一般問い合わせ/欠席 の振り分け
    │   ├── chatbot_service.py   一般問い合わせ→RAG→AI
    │   ├── absence_service.py   欠席登録・一覧・状態更新
    │   ├── auth_service.py      教員認証
    │   └── audit_service.py     操作ログ
    └── web/                     プレゼンテーション（FastAPI）
        ├── deps.py              DI（実装を生成しサービスへ注入）
        ├── parent_routes.py     保護者: チャット・欠席フォーム
        ├── admin_routes.py      教員: ログイン・管理画面・監査
        └── templates/           画面（LINE風 HTML）
```

## セキュリティ 4 要件と確認方法

| # | 要件 | 実装 | デモでの確認 |
|---|---|---|---|
| 1 | データ所有が学校側・持ち出さない | 全データはローカル `data/school.db` のみ。外部送信は AI への一般問い合わせ（非個人情報）だけ | コードに外部保存先が無いこと |
| 2 | 通信・保存の暗号化 | HTTPS(自己署名TLS)＋個人情報カラムをAES-256-GCM暗号化 | `https://` で接続／`data/school.db` を直接開くと氏名・理由が暗号化されて読めない |
| 3 | アクセス制御・操作ログ | 教員ログイン(bcrypt)＋ロール(admin/teacher)＋`audit_log` | 未ログインで `/admin`→ログインへ。監査ログは admin のみ閲覧可 |
| 4 | AIと個人情報の分離 | メッセージを振り分け、欠席経路はAI非経由。一般経路もDBの個人情報は渡さない | 「太郎が熱で休みます」→ route=absence（AI非経由）／「持ち物は？」→ route=general（AI） |

## デモシナリオ

1. 保護者トークで「持ち物について教えて」→ 学習資料を参照した回答（参照資料名が表示）。
2. 「太郎が熱で休みます」→ 振り分けが **欠席連絡（AI非経由）** になり、フォームへ誘導。
3. 欠席フォームから登録 → 完了画面。
4. 教員 `teacher/teacher` でログイン → 欠席一覧に反映 → 「対応済みに」。
5. 教員 `admin/admin` でログイン → 「監査ログ」で操作履歴を確認。
6. `data/school.db` を SQLite ビューアで開き、氏名・理由が暗号化されていることを確認。
