# -*- coding: utf-8 -*-
"""infrastructure 層 — domain/ports の具体実装（外部 I/O）。

SQLite・Bedrock・ファイル検索など「外の世界」とのやり取りをここに閉じ込める。
上位層（services）は domain/ports の抽象だけを見ればよく、ここの実装詳細
（SQL 文・SDK 呼び出し）に依存しない。
"""
