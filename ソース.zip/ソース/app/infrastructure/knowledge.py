# -*- coding: utf-8 -*-
"""ファイルベースの知識ベース実装（infrastructure 層 / RAG の検索器）。

knowledge/*.md を見出し単位のチャンクに分割し、質問との文字 2-gram の
一致数でスコアリングして関連チャンクを返す。日本語は単語境界が曖昧なため、
形態素解析を使わず文字 2-gram で素朴にマッチさせる（デモ用途として十分）。
"""
import re
from ..core.config import KNOWLEDGE_DIR
from ..domain.ports import KnowledgeBase


def _ngrams(text: str, n: int = 2) -> set[str]:
    """空白を除去した文字列の n-gram 集合を作る。"""
    s = re.sub(r"\s+", "", text)
    return {s[i:i + n] for i in range(len(s) - n + 1)}


class FileKnowledgeBase(KnowledgeBase):
    """knowledge/ 配下の Markdown を読み込む知識ベース。"""

    def __init__(self, knowledge_dir=KNOWLEDGE_DIR):
        self._dir = knowledge_dir
        self._chunks: list[tuple[str, str]] | None = None  # 遅延ロード

    def _load(self) -> list[tuple[str, str]]:
        chunks: list[tuple[str, str]] = []
        for path in sorted(self._dir.glob("*.md")):
            text = path.read_text(encoding="utf-8")
            # 見出し(#, ##, ###)の手前で分割して 1 チャンクにする
            for part in re.split(r"\n(?=#{1,3}\s)", text):
                part = part.strip()
                if len(part) >= 10:
                    chunks.append((path.name, part))
        return chunks

    def retrieve(self, query: str, k: int = 3) -> list[tuple[str, str]]:
        if self._chunks is None:
            self._chunks = self._load()
        qg = _ngrams(query or "")
        if not qg:
            return []
        scored = []
        for name, chunk in self._chunks:
            score = len(qg & _ngrams(chunk))   # 質問と本文の 2-gram 共通数
            if score > 0:
                scored.append((score, name, chunk))
        scored.sort(key=lambda x: -x[0])
        return [(name, chunk) for _, name, chunk in scored[:k]]
