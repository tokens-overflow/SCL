# -*- coding: utf-8 -*-
"""Amazon Bedrock 上の Claude を使う AI プロバイダ（infrastructure 層）。

`AnthropicBedrock` クライアント（anthropic SDK）で Bedrock の Claude を呼ぶ。
認証情報・モデル（推論プロファイル ARN）・プロンプトキャッシュ設定は
bedrock_config（外部ファイル C:\\NTA\\RooCode\\ai.txt）から読み込む。

★セキュリティ要件4: answer() に渡すのは質問文と学習資料のみ。
  児童・保護者などの個人情報はプロンプトに含めない。
  さらにシステムプロンプトで「資料にない事・個人情報には答えない」よう制約する。
"""
from ..core.config import SCHOOL_TEL
from ..domain.ports import AIProvider
from .bedrock_config import load_bedrock_config

SYSTEM_POLICY = (
    "あなたは小学校の公式案内チャットボットです。"
    "提供された【学校資料】だけを根拠に、保護者向けに丁寧で簡潔な日本語で答えてください。"
    "資料に書かれていない質問、個人情報・成績・特定児童の事情・欠席手続きの個別判断には答えず、"
    f"『恐れ入りますが、学校（電話: {SCHOOL_TEL}）へお問い合わせください』と案内してください。"
    "推測で答えてはいけません。"
    # ---- 出力フォーマット（LINE トーク向け）----
    "回答は LINE のトーク画面に表示されます。Markdown 記法は使わないでください。"
    "具体的には、見出し記号(#)、表(|...|)、太字(**)、コードブロックを使わないこと。"
    "箇条書きは行頭に「・」を使い、項目は短く改行で区切ってください。"
    "全体で3〜6行程度を目安に、やわらかい口調で簡潔にまとめてください。"
    "絵文字は1〜2個までにとどめてください。"
)


def _format_context(snippets: list[tuple[str, str]]) -> str:
    if not snippets:
        return "（該当資料なし）"
    return "\n\n".join(f"[{name}]\n{chunk}" for name, chunk in snippets)


class BedrockClaudeProvider(AIProvider):
    def __init__(self):
        cfg = load_bedrock_config()
        if not cfg:
            raise RuntimeError("Bedrock 設定が読み込めません（ai.txt 不在）")
        from anthropic import AnthropicBedrock  # 遅延 import（未導入でも他機能を阻害しない）
        self._client = AnthropicBedrock(
            aws_access_key=cfg["access_key"],
            aws_secret_key=cfg["secret_key"],
            aws_session_token=cfg["session_token"] or None,
            aws_region=cfg["region"],
        )
        self._model = cfg["model"]
        self._use_cache = cfg["use_prompt_cache"]

    @property
    def name(self) -> str:
        return "bedrock:jp.anthropic.claude-sonnet-4-6"

    def answer(self, question: str, snippets: list[tuple[str, str]]) -> str:
        context = _format_context(snippets)
        # システムプロンプトはブロック配列で渡す。prompt cache 有効時は
        # cache_control を付けて、繰り返し送る固定プロンプトをキャッシュさせる。
        system_block = {"type": "text", "text": SYSTEM_POLICY}
        if self._use_cache:
            system_block["cache_control"] = {"type": "ephemeral"}

        msg = self._client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=[system_block],
            messages=[{
                "role": "user",
                "content": f"【学校資料】\n{context}\n\n【保護者からの質問】\n{question}",
            }],
        )
        return "".join(b.text for b in msg.content if b.type == "text")
