# -*- coding: utf-8 -*-
"""AI プロバイダの生成（infrastructure 層）。

選択ロジック:
  - 環境変数 USE_BEDROCK=0 → 強制的にオフライン Stub
  - それ以外で、外部設定（ai.txt）に認証情報があれば Bedrock 上の Claude
  - 認証情報が無い／初期化に失敗 → Stub に自動フォールバック

返り値は AIProvider 抽象型なので、上位層はどちらが選ばれたかを意識しない（解耦）。
"""
import os
from ..domain.ports import AIProvider
from .ai_stub import StubAIProvider
from .ai_bedrock import BedrockClaudeProvider
from .bedrock_config import has_credentials


def build_ai_provider() -> AIProvider:
    # 明示的に Stub を強制したい場合
    if os.environ.get("USE_BEDROCK") == "0":
        print("[ai_factory] USE_BEDROCK=0 のため Stub を使用")
        return StubAIProvider()

    # 外部設定に認証情報があれば Bedrock を試行
    if has_credentials():
        try:
            provider = BedrockClaudeProvider()
            print("[ai_factory] Bedrock(Claude Sonnet 4.6) を使用")
            return provider
        except Exception as e:
            print(f"[ai_factory] Bedrock 初期化失敗、Stub に切替: {e}")

    print("[ai_factory] 認証情報なし → Stub を使用")
    return StubAIProvider()
