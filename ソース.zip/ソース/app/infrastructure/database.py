# -*- coding: utf-8 -*-
"""SQLite データベース基盤（infrastructure 層）。

役割:
  - 接続の生成（connect）
  - スキーマ作成（init）
  - デモ用シードデータの投入（_seed）

インストール不要のファイル DB（SQLite, Python 標準同梱）を使う。
個人情報カラム（name_enc / reason_enc）は暗号化して格納する（要件2）。
"""
import sqlite3
from datetime import datetime
from ..core import crypto, security

SCHEMA = """
CREATE TABLE IF NOT EXISTS classes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  grade INTEGER,
  name TEXT
);
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_no TEXT,
  name_enc TEXT,        -- 暗号化（個人情報: 児童氏名）
  kana TEXT,
  birth_date TEXT,
  class_id INTEGER
);
CREATE TABLE IF NOT EXISTS guardians(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_enc TEXT         -- 暗号化（個人情報: 保護者氏名）
);
CREATE TABLE IF NOT EXISTS guardian_student(
  guardian_id INTEGER,
  student_id INTEGER
);
CREATE TABLE IF NOT EXISTS teachers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  pw_hash TEXT,         -- bcrypt ハッシュ
  role TEXT             -- admin / teacher
);
CREATE TABLE IF NOT EXISTS absences(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER,
  date TEXT,
  type TEXT,            -- 欠席 / 遅刻 / 早退
  reason_enc TEXT,      -- 暗号化（個人情報: 欠席理由）
  source TEXT,
  status TEXT DEFAULT '未対応',
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT, actor TEXT, action TEXT,
  target_type TEXT, target_id TEXT, detail TEXT
);
CREATE TABLE IF NOT EXISTS chat_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT, channel TEXT, routed_to TEXT, message TEXT
);
"""


class Database:
    """SQLite 接続の生成と初期化を担うシンプルなラッパ。"""

    def __init__(self, db_path):
        self._db_path = str(db_path)

    def connect(self) -> sqlite3.Connection:
        """1 リクエスト/操作ごとに使い捨てる接続を返す（row は名前アクセス可）。"""
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init(self) -> None:
        """スキーマを作成し、空ならデモ用シードを投入する。"""
        conn = self.connect()
        conn.executescript(SCHEMA)
        conn.commit()
        if conn.execute("SELECT COUNT(*) AS n FROM teachers").fetchone()["n"] == 0:
            self._seed(conn)
        conn.close()

    def _seed(self, conn: sqlite3.Connection) -> None:
        """デモ用の初期データ。児童・保護者の氏名・欠席理由は暗号化して保存する。"""
        from datetime import date as _date
        today = _date.today().isoformat()

        # クラス（id 1..3）
        classes = [(1, "1年A組"), (2, "2年A組"), (3, "3年B組")]
        for grade, name in classes:
            conn.execute("INSERT INTO classes(grade,name) VALUES(?,?)", (grade, name))

        # 児童（id 1..5）／氏名は暗号化
        students = [
            ("1001", "山田 太郎", "やまだ たろう", "2017-04-10", 1),
            ("1002", "田中 美咲", "たなか みさき", "2017-06-02", 1),
            ("2010", "佐藤 花子", "さとう はなこ", "2016-09-18", 2),
            ("3015", "鈴木 一郎", "すずき いちろう", "2015-08-22", 3),
            ("3021", "高橋 結衣", "たかはし ゆい", "2015-12-05", 3),
        ]
        for no, name, kana, bd, cid in students:
            conn.execute(
                "INSERT INTO students(student_no,name_enc,kana,birth_date,class_id) "
                "VALUES(?,?,?,?,?)",
                (no, crypto.encrypt(name), kana, bd, cid))

        # 保護者（id 1..2）と児童の紐付け
        conn.execute("INSERT INTO guardians(name_enc) VALUES(?)", (crypto.encrypt("山田 一郎"),))
        conn.execute("INSERT INTO guardians(name_enc) VALUES(?)", (crypto.encrypt("佐藤 桜"),))
        conn.execute("INSERT INTO guardian_student(guardian_id,student_id) VALUES(1,1)")
        conn.execute("INSERT INTO guardian_student(guardian_id,student_id) VALUES(2,3)")

        # デモ用教員アカウント（パスワードは bcrypt ハッシュで保存）
        conn.execute("INSERT INTO teachers(username,pw_hash,role) VALUES(?,?,?)",
                     ("admin", security.hash_password("admin"), "admin"))
        conn.execute("INSERT INTO teachers(username,pw_hash,role) VALUES(?,?,?)",
                     ("teacher", security.hash_password("teacher"), "teacher"))

        # 既存の欠席連絡（本日分）／理由は暗号化。管理画面が初回から埋まる。
        now = datetime.now().isoformat(timespec="seconds")
        seed_absences = [
            (1, today, "欠席", "発熱：38.5度のため", "未対応"),
            (3, today, "遅刻", "通院：歯科のため10時頃登校", "未対応"),
            (4, today, "早退", "家庭の事情のため14時下校", "対応済み"),
        ]
        for sid, d, t, reason, status in seed_absences:
            conn.execute(
                "INSERT INTO absences(student_id,date,type,reason_enc,source,status,created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (sid, d, t, crypto.encrypt(reason), "seed", status, now))

        conn.execute(
            "INSERT INTO audit_log(ts,actor,action,target_type,target_id,detail) VALUES(?,?,?,?,?,?)",
            (now, "system", "seed", "db", "", "初期データ投入（児童5名・欠席3件）"))
        conn.commit()
