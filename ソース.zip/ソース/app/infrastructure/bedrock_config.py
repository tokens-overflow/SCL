# -*- coding: utf-8 -*-
"""Bedrock 接続設定のローダー（infrastructure 層）。

認証情報をソースに埋め込まず、外部ファイル（既定 C:\\NTA\\RooCode\\ai.txt）を
実行時に読み込んで利用する。これにより秘密情報はリポジトリ外に留まる。
環境変数 BEDROCK_CONFIG_FILE でパスを差し替え可能。

ai.txt は次のような JSON 断片（外側の波括弧なし）を想定:
    "Bedrock Claude Sonnet 4.6": { "awsAccessKey": "...", ... }
"""
import os
import json
from pathlib import Path

# RooCode の設定ファイル（apiProvider=bedrock の設定をそのまま流用）
CONFIG_PATH = Path(os.environ.get("BEDROCK_CONFIG_FILE", r"C:\NTA\RooCode\ai.txt"))


def load_bedrock_config() -> dict | None:
    """外部設定ファイルを読み、Bedrock 接続用の dict を返す。無ければ None。"""
    if not CONFIG_PATH.exists():
        return None
    try:
        text = CONFIG_PATH.read_text(encoding="utf-8").strip()
        # 外側の波括弧が無い JSON 断片なので補って読み込む
        data = json.loads("{" + text + "}")
        cfg = next(iter(data.values()))   # 単一エントリの中身を取り出す
    except Exception as e:
        print(f"[bedrock_config] 設定ファイルの解析に失敗: {e}")
        return None

    # apiModelId の {accountId} を awsAccountId で置換（推論プロファイル ARN）
    model = cfg.get("apiModelId", "").replace("{accountId}", cfg.get("awsAccountId", ""))
    return {
        "access_key": cfg.get("awsAccessKey", ""),
        "secret_key": cfg.get("awsSecretKey", ""),
        "session_token": cfg.get("awsSessionToken", ""),
        "region": cfg.get("awsRegion", "ap-northeast-1"),
        "model": model,
        "use_prompt_cache": bool(cfg.get("awsUsePromptCache", False)),
    }


def has_credentials() -> bool:
    """Bedrock を試行できる認証情報が外部設定にあるか。"""
    cfg = load_bedrock_config()
    return bool(cfg and cfg["access_key"] and cfg["secret_key"])
