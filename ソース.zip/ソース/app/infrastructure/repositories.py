# -*- coding: utf-8 -*-
"""SQLite によるリポジトリ実装（infrastructure 層）。

domain/ports.py の抽象リポジトリを SQLite で実装する。
個人情報カラムの暗号化/復号はこの層で行い、上位層へは復号済みの
ドメインモデル（models.py）として返す。
"""
from datetime import datetime

from ..core import crypto
from ..domain.models import ClassInfo, StudentView, AbsenceView, AuditEntry
from ..domain.ports import (
    StudentRepository, AbsenceRepository, TeacherRepository,
    AuditRepository, ChatLogRepository,
)
from .database import Database


class SqliteStudentRepository(StudentRepository):
    def __init__(self, db: Database):
        self._db = db

    def list_students(self) -> list[StudentView]:
        conn = self._db.connect()
        rows = conn.execute(
            "SELECT s.id, s.student_no, s.name_enc, c.name AS class_name "
            "FROM students s LEFT JOIN classes c ON s.class_id=c.id ORDER BY s.id"
        ).fetchall()
        conn.close()
        return [StudentView(
            id=r["id"], student_no=r["student_no"],
            name=crypto.decrypt(r["name_enc"]),   # ← ここで復号
            class_name=r["class_name"],
        ) for r in rows]

    def list_classes(self) -> list[ClassInfo]:
        conn = self._db.connect()
        rows = conn.execute("SELECT * FROM classes ORDER BY id").fetchall()
        conn.close()
        return [ClassInfo(id=r["id"], grade=r["grade"], name=r["name"]) for r in rows]


class SqliteAbsenceRepository(AbsenceRepository):
    def __init__(self, db: Database):
        self._db = db

    def create(self, student_id, date, type_, reason, source) -> int:
        conn = self._db.connect()
        cur = conn.execute(
            "INSERT INTO absences(student_id,date,type,reason_enc,source,status,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (student_id, date, type_, crypto.encrypt(reason), source, "未対応",
             datetime.now().isoformat(timespec="seconds")))
        conn.commit()
        aid = cur.lastrowid
        conn.close()
        return aid

    def list(self, date, class_id, type_) -> list[AbsenceView]:
        conn = self._db.connect()
        q = ("SELECT a.*, s.name_enc, s.student_no, c.name AS class_name, c.id AS cid "
             "FROM absences a JOIN students s ON a.student_id=s.id "
             "LEFT JOIN classes c ON s.class_id=c.id WHERE 1=1")
        params = []
        if date:
            q += " AND a.date=?"; params.append(date)
        if class_id:
            q += " AND c.id=?"; params.append(class_id)
        if type_:
            q += " AND a.type=?"; params.append(type_)
        q += " ORDER BY a.date DESC, a.id DESC"
        rows = conn.execute(q, params).fetchall()
        conn.close()
        return [AbsenceView(
            id=r["id"], date=r["date"], type=r["type"],
            reason=crypto.decrypt(r["reason_enc"]),     # ← 復号
            status=r["status"], source=r["source"],
            student_name=crypto.decrypt(r["name_enc"]), # ← 復号
            student_no=r["student_no"], class_name=r["class_name"],
        ) for r in rows]

    def update_status(self, absence_id, status) -> None:
        conn = self._db.connect()
        conn.execute("UPDATE absences SET status=? WHERE id=?", (status, absence_id))
        conn.commit()
        conn.close()


class SqliteTeacherRepository(TeacherRepository):
    def __init__(self, db: Database):
        self._db = db

    def get_by_username(self, username) -> dict | None:
        conn = self._db.connect()
        r = conn.execute("SELECT * FROM teachers WHERE username=?", (username,)).fetchone()
        conn.close()
        if not r:
            return None
        return {"id": r["id"], "username": r["username"],
                "pw_hash": r["pw_hash"], "role": r["role"]}


class SqliteAuditRepository(AuditRepository):
    def __init__(self, db: Database):
        self._db = db

    def add(self, actor, action, target_type, target_id, detail) -> None:
        conn = self._db.connect()
        conn.execute(
            "INSERT INTO audit_log(ts,actor,action,target_type,target_id,detail) "
            "VALUES(?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), actor, action,
             target_type, str(target_id), detail))
        conn.commit()
        conn.close()

    def list(self, limit=300) -> list[AuditEntry]:
        conn = self._db.connect()
        rows = conn.execute(
            "SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        conn.close()
        return [AuditEntry(
            id=r["id"], ts=r["ts"], actor=r["actor"], action=r["action"],
            target_type=r["target_type"], target_id=r["target_id"], detail=r["detail"],
        ) for r in rows]


class SqliteChatLogRepository(ChatLogRepository):
    def __init__(self, db: Database):
        self._db = db

    def add(self, channel, routed_to, message) -> None:
        conn = self._db.connect()
        conn.execute(
            "INSERT INTO chat_logs(ts,channel,routed_to,message) VALUES(?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), channel, routed_to, message))
        conn.commit()
        conn.close()
