# -*- coding: utf-8 -*-
"""オフライン Stub の AI プロバイダ（infrastructure 層）。

AWS 認証が無くてもデモが動くよう、Bedrock を使わずに「検索でヒットした
学習資料の本文」をそのまま整形して返す簡易応答器。AIProvider を実装。
"""
from ..core.config import SCHOOL_TEL
from ..domain.ports import AIProvider


class StubAIProvider(AIProvider):
    @property
    def name(self) -> str:
        return "stub(offline)"

    def answer(self, question: str, snippets: list[tuple[str, str]]) -> str:
        # 資料にヒットしなければ、推測せず学校窓口へ誘導する
        if not snippets:
            return (f"恐れ入りますが、その内容は資料に見つかりませんでした。"
                    f"お手数ですが学校（電話: {SCHOOL_TEL}）へお問い合わせください。")
        name, chunk = snippets[0]
        # 見出し行(#…)を除いた本文だけを抜き出して提示
        body = "\n".join(
            ln for ln in chunk.splitlines() if not ln.lstrip().startswith("#")
        ).strip()
        return (f"学校資料『{name}』よりご案内します。\n\n{body[:400]}\n\n"
                f"（詳しくは学校までお問い合わせください）")
