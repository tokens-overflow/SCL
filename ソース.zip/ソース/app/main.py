# -*- coding: utf-8 -*-
"""アプリ起動エントリ（web 層 / アプリ組み立て）。

FastAPI 本体を生成し、セッションミドルウェア・各ルータを取り付ける。
起動時に DB を初期化（スキーマ作成 + シード投入）する。

起動: ソース/ ディレクトリで
    python -m uvicorn app.main:app --ssl-keyfile certs/key.pem --ssl-certfile certs/cert.pem
"""
from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from starlette.middleware.sessions import SessionMiddleware

from .core.config import get_session_secret
from .web import deps
from .web.parent_routes import router as parent_router
from .web.admin_routes import router as admin_router

app = FastAPI(title="LINE 学校 DX デモ")

# 教員ログイン状態を署名付き Cookie で保持（要件3）
app.add_middleware(SessionMiddleware, secret_key=get_session_secret())

# 起動時に DB を用意（初回はシードデータも投入）
deps.database.init()

# ルータ登録
app.include_router(parent_router)
app.include_router(admin_router)


@app.get("/")
def root():
    """トップは保護者トーク画面へ。"""
    return RedirectResponse("/parent")
