# -*- coding: utf-8 -*-
"""パスワードのハッシュ化・照合（core 層 / セキュリティ要件3: アクセス制御の基盤）。

教員アカウントのパスワードは平文では保存せず、bcrypt でハッシュ化して
保持する。bcrypt はソルトを内包し、計算コストが高いため総当たり攻撃に強い。
"""
import bcrypt


def hash_password(password: str) -> str:
    """平文パスワード → bcrypt ハッシュ文字列。"""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    """平文パスワードがハッシュに一致するか判定する。"""
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False
