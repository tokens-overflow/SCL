# -*- coding: utf-8 -*-
"""個人情報のフィールド暗号化（core 層 / セキュリティ要件2: encryption at rest）。

児童氏名・保護者氏名・欠席理由などの個人情報は、SQLite に平文で保存せず
AES-256-GCM（認証付き暗号）で暗号化して保持する。これにより、DB ファイル
（data/school.db）が単体で流出しても内容を読めない。

鍵はローカルの data/aes.key に保存する。
※本番環境では AWS KMS / Secrets Manager 等のキー管理サービスに置き換える前提。
"""
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .config import KEY_PATH


def _load_or_create_key() -> bytes:
    """AES-256 鍵をロード。無ければ生成してローカル保存する。"""
    if KEY_PATH.exists():
        return base64.b64decode(KEY_PATH.read_text(encoding="utf-8").strip())
    key = AESGCM.generate_key(bit_length=256)
    KEY_PATH.write_text(base64.b64encode(key).decode(), encoding="utf-8")
    return key


# モジュール読込時に鍵を 1 度だけ初期化（暗号器を使い回す）
_AES = AESGCM(_load_or_create_key())


def encrypt(plaintext: str) -> str:
    """平文文字列を暗号化し base64(nonce + 暗号文) を返す。

    GCM では毎回ランダムな nonce(12byte) を使うため、同じ平文でも
    毎回異なる暗号文になる（安全性のため）。
    """
    if plaintext is None:
        plaintext = ""
    nonce = os.urandom(12)
    ct = _AES.encrypt(nonce, plaintext.encode("utf-8"), None)
    return base64.b64encode(nonce + ct).decode()


def decrypt(token: str) -> str:
    """encrypt() が返した文字列を復号して平文を返す。"""
    if not token:
        return ""
    raw = base64.b64decode(token)
    nonce, ct = raw[:12], raw[12:]
    return _AES.decrypt(nonce, ct, None).decode("utf-8")
