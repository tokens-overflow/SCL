# -*- coding: utf-8 -*-
"""自己署名 TLS 証明書の生成（core 層 / セキュリティ要件2: 通信暗号化）。

localhost を HTTPS(TLS) で提供するための証明書・秘密鍵を生成する。
openssl コマンドに依存せず、cryptography ライブラリだけで完結する。
※本番では ACM 等の正規 CA 証明書に置き換える前提（自己署名はデモ用）。

  python -m app.core.tls   で単体実行して証明書を生成できる。
"""
import datetime
import ipaddress
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from .config import CERTS_DIR

CERT = CERTS_DIR / "cert.pem"
KEY = CERTS_DIR / "key.pem"


def ensure_cert():
    """証明書が無ければ生成し、(cert_path, key_path) を返す。"""
    if CERT.exists() and KEY.exists():
        return CERT, KEY

    # 2048bit RSA 秘密鍵
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
    now = datetime.datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)              # 自己署名（subject == issuer）
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=825))
        .add_extension(
            x509.SubjectAlternativeName([
                x509.DNSName("localhost"),
                x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
            ]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    KEY.write_bytes(key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    ))
    CERT.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return CERT, KEY


if __name__ == "__main__":
    c, k = ensure_cert()
    print(f"[tls] cert: {c}")
    print(f"[tls] key : {k}")
