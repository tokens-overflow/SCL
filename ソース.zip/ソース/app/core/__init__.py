# -*- coding: utf-8 -*-
"""core 層 — 横断的関心事（設定・暗号・認証基盤・TLS）。

どの層からも利用される最も低レベルなユーティリティを集約する。
他の層（domain / infrastructure / services / web）に依存しない。
"""
