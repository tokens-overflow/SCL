# -*- coding: utf-8 -*-
"""アプリ全体の設定・パス定義（core 層）。

役割:
  - データ・証明書・暗号鍵の保存先パスを一元管理する。
  - すべて BASE_DIR(=ソース) 配下のローカルに置き、外部へ持ち出さない。
    （セキュリティ要件1: 個人データの所有・保管は学校側に置く）
  - AI プロバイダの選択（オフライン Stub / Bedrock 上の Claude）を環境変数で切替。

この層は他のどの層にも依存しない（依存方向の最下層）。
"""
import os
import base64
from pathlib import Path

# ---- ディレクトリ ----
# このファイルは ソース/app/core/config.py にある。
#   parents[0] = core, parents[1] = app, parents[2] = ソース
BASE_DIR = Path(__file__).resolve().parents[2]   # = ソース/
DATA_DIR = BASE_DIR / "data"                       # SQLite / 暗号鍵（.gitignore 対象）
CERTS_DIR = BASE_DIR / "certs"                     # 自己署名証明書（.gitignore 対象）
KNOWLEDGE_DIR = BASE_DIR / "knowledge"             # チャットボットの学習資料（コミット対象）

# 実行時に無ければ作成（初回起動を成立させる）
DATA_DIR.mkdir(exist_ok=True)
CERTS_DIR.mkdir(exist_ok=True)

# ---- ファイルパス ----
DB_PATH = DATA_DIR / "school.db"                   # SQLite データベース本体
KEY_PATH = DATA_DIR / "aes.key"                    # 個人情報暗号化のための AES 鍵
SESSION_SECRET_PATH = DATA_DIR / "session.secret"  # 教員セッション Cookie の署名鍵

# ---- AI プロバイダ設定 ----
# 既定はオフライン Stub（AWS 認証不要でデモが動く）。
# USE_BEDROCK=1 かつ AWS 認証が通れば Bedrock 上の Claude を使う。
USE_BEDROCK = os.environ.get("USE_BEDROCK", "0") == "1"
BEDROCK_MODEL = os.environ.get("BEDROCK_MODEL", "apac.anthropic.claude-sonnet-4-6")
BEDROCK_REGION = os.environ.get("AWS_REGION", "ap-northeast-1")

# ---- 学校情報 ----
# AI が答えられない/答えるべきでない場合の誘導先電話番号。
SCHOOL_TEL = os.environ.get("SCHOOL_TEL", "03-XXXX-XXXX")


def get_session_secret() -> str:
    """教員セッション Cookie 署名用の秘密鍵を取得する。

    初回はランダム生成してローカルに保存し、以降は再利用する
    （再起動でログインセッションが無効化されないようにするため）。
    """
    if SESSION_SECRET_PATH.exists():
        return SESSION_SECRET_PATH.read_text(encoding="utf-8").strip()
    secret = base64.b64encode(os.urandom(32)).decode()
    SESSION_SECRET_PATH.write_text(secret, encoding="utf-8")
    return secret
