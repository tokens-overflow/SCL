# -*- coding: utf-8 -*-
"""保護者向けルート（web 層）。

  - GET  /parent          … LINE 風トーク画面
  - POST /api/chat        … メッセージ振り分け + 一般問い合わせは AI 応答
  - GET  /liff/absence    … LIFF 風 欠席フォーム
  - POST /api/absence     … 欠席連絡の登録
"""
from datetime import date as date_cls
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse

from .deps import (
    TEMPLATES, message_router, chatbot_service, absence_service,
    chatlog_repo, audit_service,
)

router = APIRouter()


@router.get("/parent", response_class=HTMLResponse)
def parent(request: Request):
    # Starlette 新シグネチャ: TemplateResponse(request, name, context)
    return TEMPLATES.TemplateResponse(request, "parent_chat.html")


@router.post("/api/chat")
async def api_chat(request: Request):
    """★要件4 の本体: メッセージを振り分け、欠席は AI に渡さない。"""
    data = await request.json()
    message = (data.get("message") or "").strip()
    route, reason = message_router.classify(message)

    if route == "absence":
        # 欠席（個人情報を含みうる）→ AI に渡さず、本文も保存しない。
        chatlog_repo.add("parent", "absence", "[欠席意図のため本文は保存しません]")
        audit_service.record("保護者(LINE)", "chat_route", "chat", "", f"route=absence ({reason})")
        return JSONResponse({
            "route": route, "reason": reason,
            "reply": "欠席・遅刻・早退のご連絡ですね。下のフォームからお願いします 👇",
            "action": "absence_form",
        })

    # 一般問い合わせ → AI（個人情報は渡さない）
    reply, provider, sources = chatbot_service.answer(message)
    chatlog_repo.add("parent", "general", message)
    audit_service.record("保護者(LINE)", "chat_route", "chat", "", f"route=general provider={provider}")
    return JSONResponse({
        "route": route, "reason": reason,
        "reply": reply, "provider": provider, "sources": sources,
    })


@router.get("/liff/absence", response_class=HTMLResponse)
def liff_absence(request: Request):
    return TEMPLATES.TemplateResponse(request, "liff_absence.html", {
        "students": absence_service.students_for_form(),
        "today": date_cls.today().isoformat(),
    })


@router.post("/api/absence")
def api_absence(
    student_id: int = Form(...),
    date: str = Form(...),
    type: str = Form(...),
    reason_kind: str = Form(""),
    reason_text: str = Form(""),
):
    aid = absence_service.register(
        student_id, date, type, reason_kind, reason_text, actor="保護者(LINE)")
    return JSONResponse({"ok": True, "id": aid})
