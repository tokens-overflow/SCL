# -*- coding: utf-8 -*-
"""教員向けルート（web 層 / セキュリティ要件3: 認証・ロール・監査）。

  - GET/POST /admin/login          … ログイン（bcrypt 照合）
  - GET      /admin/logout         … ログアウト
  - GET      /admin                … 欠席一覧（要ログイン、フィルタ）
  - POST     /admin/absence/{id}/status … 状態更新（要ログイン）
  - GET      /admin/audit          … 監査ログ（admin ロールのみ）
"""
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse

from .deps import (
    TEMPLATES, auth_service, absence_service, audit_service,
    student_repo, current_teacher,
)

router = APIRouter(prefix="/admin")


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return TEMPLATES.TemplateResponse(request, "login.html", {"error": None})


@router.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    teacher = auth_service.authenticate(username, password)
    if teacher:
        request.session["teacher"] = teacher
        return RedirectResponse("/admin", status_code=302)
    return TEMPLATES.TemplateResponse(
        request, "login.html", {"error": "ユーザー名またはパスワードが違います"})


@router.get("/logout")
def logout(request: Request):
    request.session.pop("teacher", None)
    return RedirectResponse("/admin/login", status_code=302)


@router.get("", response_class=HTMLResponse)
def admin_home(request: Request, date: str = "", class_id: str = "", type: str = ""):
    t = current_teacher(request)
    if not t:
        return RedirectResponse("/admin/login", status_code=302)
    cid = int(class_id) if class_id else None
    rows = absence_service.list_for_admin(date or None, cid, type or None, actor=t["username"])
    return TEMPLATES.TemplateResponse(request, "admin.html", {
        "teacher": t, "rows": rows,
        "classes": student_repo.list_classes(),   # フィルタ用クラス一覧
        "f": {"date": date, "class_id": class_id, "type": type},
    })


@router.post("/absence/{absence_id}/status")
def update_status(request: Request, absence_id: int, status: str = Form(...)):
    t = current_teacher(request)
    if not t:
        return RedirectResponse("/admin/login", status_code=302)
    absence_service.mark_status(absence_id, status, actor=t["username"])
    return RedirectResponse("/admin", status_code=302)


@router.get("/audit", response_class=HTMLResponse)
def audit_view(request: Request):
    t = current_teacher(request)
    if not t:
        return RedirectResponse("/admin/login", status_code=302)
    if t["role"] != "admin":
        # ★ロールによる閲覧制限: 監査ログは admin のみ
        return HTMLResponse(
            "<h3>権限がありません（admin のみ閲覧可）</h3><a href='/admin'>戻る</a>",
            status_code=403)
    return TEMPLATES.TemplateResponse(request, "audit.html", {
        "teacher": t, "logs": audit_service.recent()})
