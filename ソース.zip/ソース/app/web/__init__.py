# -*- coding: utf-8 -*-
"""web 層 — プレゼンテーション（FastAPI ルート + 画面）。

HTTP リクエストを受け取り、services 層を呼び出して結果を画面/JSON で返す。
具体実装の組み立て（DI）は deps.py に集約する（composition root）。
"""
