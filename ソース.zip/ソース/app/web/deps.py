# -*- coding: utf-8 -*-
"""依存組み立て（web 層 / composition root）。

ここで「具体実装（infrastructure）」を生成し、「サービス（services）」へ
注入する。各層は抽象（ports）にのみ依存し、どの実装を使うかはこの 1 か所で
決まる。実装を差し替えたい場合（DB や AI を変える）も、原則ここだけ直せばよい。
"""
from pathlib import Path
from fastapi import Request
from fastapi.templating import Jinja2Templates

from ..core.config import DB_PATH
from ..infrastructure.database import Database
from ..infrastructure.repositories import (
    SqliteStudentRepository, SqliteAbsenceRepository, SqliteTeacherRepository,
    SqliteAuditRepository, SqliteChatLogRepository,
)
from ..infrastructure.knowledge import FileKnowledgeBase
from ..infrastructure.ai_factory import build_ai_provider
from ..infrastructure.ai_stub import StubAIProvider
from ..services.audit_service import AuditService
from ..services.absence_service import AbsenceService
from ..services.auth_service import AuthService
from ..services.chatbot_service import ChatbotService
from ..services.message_router import MessageRouter

# ---- インフラ（具体実装）----
database = Database(DB_PATH)
student_repo = SqliteStudentRepository(database)
_absence_repo = SqliteAbsenceRepository(database)
_teacher_repo = SqliteTeacherRepository(database)
_audit_repo = SqliteAuditRepository(database)
chatlog_repo = SqliteChatLogRepository(database)

# ---- サービス（抽象に依存。実装を注入）----
audit_service = AuditService(_audit_repo)
absence_service = AbsenceService(_absence_repo, student_repo, audit_service)
auth_service = AuthService(_teacher_repo, audit_service)
chatbot_service = ChatbotService(
    build_ai_provider(), FileKnowledgeBase(), fallback=StubAIProvider())
message_router = MessageRouter()

# ---- 画面テンプレート ----
TEMPLATES = Jinja2Templates(
    directory=str(Path(__file__).resolve().parent.parent / "templates"))


def current_teacher(request: Request) -> dict | None:
    """ログイン中の教員 {username, role} or None（セッションから取得）。"""
    return request.session.get("teacher")
