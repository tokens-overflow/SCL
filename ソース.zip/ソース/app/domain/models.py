# -*- coding: utf-8 -*-
"""ドメインモデル（domain 層）。

層をまたいで受け渡しする「表示・処理用のデータ構造」を定義する。
個人情報は、この層に来る時点では復号済みの平文を持つ（暗号化/復号は
infrastructure 層の責務）。DB の行(Row)ではなく型付きの dataclass を使い、
上位層（services / web）が DB スキーマに直接依存しないようにする。
"""
from dataclasses import dataclass


@dataclass
class ClassInfo:
    """クラス（学年・組）。"""
    id: int
    grade: int
    name: str


@dataclass
class StudentView:
    """欠席フォーム等で表示する児童情報（氏名は復号済み）。"""
    id: int
    student_no: str
    name: str
    class_name: str


@dataclass
class AbsenceView:
    """教員管理画面に表示する欠席連絡 1 件（理由・児童名は復号済み）。"""
    id: int
    date: str
    type: str          # 欠席 / 遅刻 / 早退
    reason: str
    status: str        # 未対応 / 対応済み
    source: str        # liff など
    student_name: str
    student_no: str
    class_name: str


@dataclass
class Teacher:
    """ログイン中の教員（パスワードハッシュは含めない）。"""
    id: int
    username: str
    role: str          # admin / teacher


@dataclass
class AuditEntry:
    """監査ログ 1 件（いつ・誰が・何を）。"""
    id: int
    ts: str
    actor: str
    action: str
    target_type: str
    target_id: str
    detail: str
