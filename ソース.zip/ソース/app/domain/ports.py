# -*- coding: utf-8 -*-
"""抽象インターフェース＝ポート（domain 層）。

services 層はここで定義する抽象クラス（ABC）にのみ依存し、
infrastructure 層がこれらを実装する。これにより:
  - AI を Stub ↔ Bedrock に差し替えても services は変更不要
  - DB を SQLite ↔ 別DB に差し替えても services は変更不要
という「依存性逆転（DIP）」を実現し、結合を弱める（解耦）。
"""
import abc
from .models import ClassInfo, StudentView, AbsenceView, AuditEntry


# ============== リポジトリ（永続化の抽象）==============

class StudentRepository(abc.ABC):
    """児童・クラスの参照。"""

    @abc.abstractmethod
    def list_students(self) -> list[StudentView]:
        ...

    @abc.abstractmethod
    def list_classes(self) -> list[ClassInfo]:
        ...


class AbsenceRepository(abc.ABC):
    """欠席連絡の作成・参照・更新。"""

    @abc.abstractmethod
    def create(self, student_id: int, date: str, type_: str, reason: str, source: str) -> int:
        ...

    @abc.abstractmethod
    def list(self, date: str | None, class_id: int | None, type_: str | None) -> list[AbsenceView]:
        ...

    @abc.abstractmethod
    def update_status(self, absence_id: int, status: str) -> None:
        ...


class TeacherRepository(abc.ABC):
    """教員アカウントの参照。"""

    @abc.abstractmethod
    def get_by_username(self, username: str) -> dict | None:
        """{id, username, pw_hash, role} or None。pw_hash 照合は呼び出し側。"""
        ...


class AuditRepository(abc.ABC):
    """監査ログの記録・参照。"""

    @abc.abstractmethod
    def add(self, actor: str, action: str, target_type: str, target_id: str, detail: str) -> None:
        ...

    @abc.abstractmethod
    def list(self, limit: int = 300) -> list[AuditEntry]:
        ...


class ChatLogRepository(abc.ABC):
    """チャットの振り分けログ（個人情報は保存しない方針）。"""

    @abc.abstractmethod
    def add(self, channel: str, routed_to: str, message: str) -> None:
        ...


# ============== AI / 知識ベース（外部頭脳の抽象）==============

class KnowledgeBase(abc.ABC):
    """学習資料の検索（RAG の検索器）。"""

    @abc.abstractmethod
    def retrieve(self, query: str, k: int = 3) -> list[tuple[str, str]]:
        """関連スニペット [(資料名, 本文), ...] を返す。"""
        ...


class AIProvider(abc.ABC):
    """質問への回答生成（Stub / Bedrock Claude を差し替え可能にする）。

    ★セキュリティ要件4: answer() は質問文と学習資料のみを受け取り、
      児童・保護者などの個人情報は一切受け取らない設計とする。
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        ...

    @abc.abstractmethod
    def answer(self, question: str, snippets: list[tuple[str, str]]) -> str:
        ...
