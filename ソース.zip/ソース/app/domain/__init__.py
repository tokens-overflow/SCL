# -*- coding: utf-8 -*-
"""domain 層 — 業務の中核（モデル定義 + 抽象インターフェース）。

ここには「何を扱うか（models）」と「外部とどう関わるかの約束事（ports）」
だけを置く。具体的な DB や AI の実装は持たない。
services 層はこの抽象（ports）にのみ依存し、infrastructure 層がそれを実装する
ことで、実装の差し替え（SQLite↔他DB、Stub↔Bedrock）が容易になる（依存性逆転）。
"""
