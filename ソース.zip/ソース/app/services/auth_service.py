# -*- coding: utf-8 -*-
"""教員認証サービス（services 層 / セキュリティ要件3: アクセス制御）。

ユーザー名+パスワードを検証し、成否を監査ログに残す。
パスワード照合は core.security（bcrypt）に委譲する。
"""
from ..core import security
from ..domain.ports import TeacherRepository
from .audit_service import AuditService


class AuthService:
    def __init__(self, teachers: TeacherRepository, audit: AuditService):
        self._teachers = teachers
        self._audit = audit

    def authenticate(self, username: str, password: str) -> dict | None:
        """認証成功なら {username, role} を、失敗なら None を返す。"""
        t = self._teachers.get_by_username(username)
        if t and security.verify_password(password, t["pw_hash"]):
            self._audit.record(username, "login", "teacher", t["id"], "success")
            return {"username": t["username"], "role": t["role"]}
        # 失敗も記録（不正アクセスの追跡のため）
        self._audit.record(username, "login", "teacher", "", "fail")
        return None
