# -*- coding: utf-8 -*-
"""欠席連絡サービス（services 層）。

保護者からの欠席登録、教員向けの一覧取得、状態更新を担う。
すべての参照・変更操作で監査ログを残す（セキュリティ要件3）。
個人情報の暗号化/復号は infrastructure 層（リポジトリ）が担うため、
このサービスは平文のドメインモデルを扱うだけでよい。
"""
from ..domain.ports import AbsenceRepository, StudentRepository
from ..domain.models import StudentView, AbsenceView
from .audit_service import AuditService


class AbsenceService:
    def __init__(self, absences: AbsenceRepository, students: StudentRepository,
                 audit: AuditService):
        self._absences = absences
        self._students = students
        self._audit = audit

    def students_for_form(self) -> list[StudentView]:
        """欠席フォームで選択させる児童一覧。"""
        return self._students.list_students()

    def register(self, student_id: int, date: str, type_: str,
                 reason_kind: str, reason_text: str, actor: str) -> int:
        """欠席連絡を登録する（保護者 LIFF フォームから）。"""
        reason = reason_kind + (("：" + reason_text) if reason_text else "")
        aid = self._absences.create(student_id, date, type_, reason, source="liff")
        self._audit.record(actor, "create_absence", "absence", aid, f"type={type_}")
        return aid

    def list_for_admin(self, date, class_id, type_, actor: str) -> list[AbsenceView]:
        """教員向けに欠席一覧を取得し、閲覧操作を監査ログに残す。"""
        rows = self._absences.list(date, class_id, type_)
        self._audit.record(actor, "view_absences", "absence", "",
                           f"date={date} class={class_id} type={type_} count={len(rows)}")
        return rows

    def mark_status(self, absence_id: int, status: str, actor: str) -> None:
        """対応状態を更新する（例: 未対応 → 対応済み）。"""
        self._absences.update_status(absence_id, status)
        self._audit.record(actor, "update_absence", "absence", absence_id, f"status={status}")
