# -*- coding: utf-8 -*-
"""監査サービス（services 層 / セキュリティ要件3: 操作ログ）。

AuditRepository（抽象）に委譲して、操作ログの記録と参照を提供する。
他サービス（欠席・認証）はこのサービス経由でログを残す。
"""
from ..domain.ports import AuditRepository
from ..domain.models import AuditEntry


class AuditService:
    def __init__(self, repo: AuditRepository):
        self._repo = repo

    def record(self, actor: str, action: str, target_type: str = "",
               target_id="", detail: str = "") -> None:
        """操作を 1 件記録する（いつ・誰が・何を）。"""
        self._repo.add(actor, action, target_type, str(target_id), detail)

    def recent(self, limit: int = 300) -> list[AuditEntry]:
        """新しい順に監査ログを取得する。"""
        return self._repo.list(limit)
