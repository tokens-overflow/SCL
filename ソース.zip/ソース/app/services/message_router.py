# -*- coding: utf-8 -*-
"""メッセージ振り分けサービス（services 層 / ★セキュリティ要件4 の核）。

受信メッセージを 2 経路に振り分ける:
  - "absence" … 欠席・遅刻・早退の連絡（児童名など個人情報を含みやすい）
                → AI には一切渡さず、構造化フォームへ誘導する
  - "general" … 一般的な問い合わせ（持ち物・行事など）
                → AI へ（ただし個人情報は渡さない）

この振り分けにより「個人情報が AI に流れる経路」を構造的に断つ。
"""


class MessageRouter:
    # 欠席連絡を示すキーワード（いずれか含めば absence と判定）
    ABSENCE_KEYWORDS = [
        "欠席", "休み", "休む", "お休み", "やすみ", "欠席連絡",
        "遅刻", "ちこく", "早退", "そうたい",
        "熱", "発熱", "風邪", "かぜ", "インフル", "コロナ",
        "通院", "病院", "体調", "腹痛", "頭痛", "嘔吐", "下痢",
    ]

    def classify(self, message: str) -> tuple[str, str]:
        """(route, reason) を返す。route は "absence" | "general"。"""
        text = message or ""
        for kw in self.ABSENCE_KEYWORDS:
            if kw in text:
                return "absence", f"「{kw}」を検知 → 欠席連絡として処理（AI非経由）"
        return "general", "一般的な問い合わせ → AIで応答"
