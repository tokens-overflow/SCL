# -*- coding: utf-8 -*-
"""チャットボットサービス（services 層）。

一般問い合わせに対して、知識ベースから関連資料を検索し、AI プロバイダで
回答を生成する（RAG）。AIProvider / KnowledgeBase はいずれも抽象（ports）
なので、Stub でも Bedrock でも、資料の差し替えでも、この層は変わらない。

★セキュリティ要件4: 渡すのは質問文と資料スニペットのみ。個人情報は渡さない。

可用性のため、主プロバイダ（例: Bedrock）が実行時に失敗した場合は
フォールバックプロバイダ（例: Stub）へ切り替える。
"""
from ..domain.ports import AIProvider, KnowledgeBase


class ChatbotService:
    def __init__(self, ai: AIProvider, knowledge: KnowledgeBase,
                 fallback: AIProvider | None = None):
        self._ai = ai
        self._knowledge = knowledge
        self._fallback = fallback

    def answer(self, question: str) -> tuple[str, str, list[str]]:
        """(回答文, 使用プロバイダ名, 参照資料名リスト) を返す。"""
        snippets = self._knowledge.retrieve(question, k=3)
        try:
            reply = self._ai.answer(question, snippets)
            provider_name = self._ai.name
        except Exception as e:
            # Bedrock の認証失敗・ネットワーク不通などはここで吸収
            if self._fallback is None:
                raise
            print(f"[chatbot] 主AI失敗のためフォールバック: {e}")
            reply = self._fallback.answer(question, snippets)
            provider_name = self._fallback.name + "(fallback)"
        sources = [name for name, _ in snippets]
        return reply, provider_name, sources
