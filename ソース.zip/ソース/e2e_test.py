# -*- coding: utf-8 -*-
"""エンドツーエンド検証（完全閉環）。

FastAPI の TestClient でアプリを「プロセス内」で直接叩くため、サーバ起動も
TLS 証明書も不要。保護者チャット → 振り分け → 欠席登録 → 教員ログイン →
一覧確認 → 状態更新 → 監査ログ → 暗号化(at rest) まで一気通貫で検証する。

実行: ソース/ ディレクトリで  python e2e_test.py
"""
import sys
import sqlite3

sys.stdout.reconfigure(encoding="utf-8")  # cp936 端末でも日本語を出力できるように

from fastapi.testclient import TestClient
from app.main import app
from app.web import deps

client = TestClient(app)

_passed = 0
_failed = 0


def check(cond, msg):
    global _passed, _failed
    mark = "OK " if cond else "NG "
    print(f"  [{mark}] {msg}")
    if cond:
        _passed += 1
    else:
        _failed += 1


print("=" * 60)
print(" LINE 学校 DX デモ  完全閉環 E2E テスト")
print("=" * 60)

# --- 1. 保護者: 一般問い合わせ → AI(Stub)応答 + 資料参照 ---
print("\n【1】保護者チャット: 一般問い合わせ（持ち物について教えて）")
d = client.post("/api/chat", json={"message": "持ち物について教えて"}).json()
check(d["route"] == "general", f"general に振り分け (route={d['route']})")
check(len(d.get("sources", [])) > 0, f"学習資料を参照した (sources={d.get('sources')})")
check("provider" in d, f"AIプロバイダ経由 (provider={d.get('provider')})")
print("       AI応答:", d["reply"][:50].replace("\n", " "), "...")

# --- 2. 保護者: 欠席意図 → AI 非経由（要件4）---
print("\n【2】保護者チャット: 欠席意図（太郎が熱で休みます）")
d = client.post("/api/chat", json={"message": "太郎が熱で休みます"}).json()
check(d["route"] == "absence", f"absence に振り分け (route={d['route']})")
check(d.get("action") == "absence_form", "欠席フォームへ誘導")
check("provider" not in d, "AIプロバイダを呼んでいない（個人情報を渡さない）")

# --- 3. 保護者: 欠席フォーム表示 + 送信 ---
print("\n【3】保護者: 欠席フォーム送信")
html = client.get("/liff/absence").text
check("山田" in html, "フォームに児童一覧が表示される（復号済み）")
res = client.post("/api/absence", data={
    "student_id": 1, "date": "2026-06-15", "type": "欠席",
    "reason_kind": "発熱", "reason_text": "38度の発熱",
}).json()
aid = res.get("id")
check(res.get("ok") and aid, f"欠席連絡を登録 (id={aid})")

# --- 4. 認可: 未ログインで /admin は弾かれる ---
print("\n【4】アクセス制御: 未ログインで管理画面へ")
r = client.get("/admin", follow_redirects=False)
check(r.status_code in (302, 307) and "/admin/login" in r.headers.get("location", ""),
      "未ログインはログイン画面へリダイレクト")

# --- 5. 教員(teacher)ログイン → 一覧に反映 ---
print("\n【5】教員ログイン(teacher) → 欠席一覧")
r = client.post("/admin/login", data={"username": "teacher", "password": "teacher"},
                follow_redirects=False)
check(r.status_code in (302, 307), "teacher ログイン成功")
html = client.get("/admin").text
check("山田 太郎" in html and "発熱" in html, "管理画面に欠席が復号表示される")

# --- 6. ロール制御: teacher は監査ログ閲覧不可 ---
print("\n【6】ロール制御: teacher は監査ログ閲覧不可")
r = client.get("/admin/audit")
check(r.status_code == 403, f"teacher の監査ログアクセスは 403 (status={r.status_code})")

# --- 7. 状態更新（未対応 → 対応済み）---
print("\n【7】欠席の状態更新")
r = client.post(f"/admin/absence/{aid}/status", data={"status": "対応済み"},
                follow_redirects=False)
check(r.status_code in (302, 307), "状態更新リクエスト成功")
html = client.get(f"/admin?type=欠席").text
check("対応済み" in html, "一覧に『対応済み』が反映")

# --- 8. admin ログイン → 監査ログ閲覧可 ---
print("\n【8】教員ログイン(admin) → 監査ログ")
client.post("/admin/login", data={"username": "admin", "password": "admin"},
            follow_redirects=False)
html = client.get("/admin/audit").text
check("create_absence" in html, "監査ログに欠席登録の記録がある")
check("view_absences" in html, "監査ログに一覧閲覧の記録がある")
check("login" in html, "監査ログにログインの記録がある")

# --- 9. 暗号化 at rest: DB を直接読むと理由は暗号文 ---
print("\n【9】保存時暗号化(at rest)の確認")
raw = sqlite3.connect(deps.database._db_path).execute(
    "SELECT reason_enc FROM absences WHERE id=?", (aid,)).fetchone()[0]
check("発熱" not in raw and "度" not in raw, f"DB上は暗号文（先頭: {raw[:24]}...）")
# アプリ経由なら復号できることも確認
rows = [a for a in deps.absence_service._absences.list("2026-06-15", None, None) if a.id == aid]
check(rows and rows[0].reason == "発熱：38度の発熱", "アプリ経由では正しく復号される")

# --- 結果 ---
print("\n" + "=" * 60)
print(f" 結果: {_passed} 件成功 / {_failed} 件失敗")
print("=" * 60)
sys.exit(1 if _failed else 0)
